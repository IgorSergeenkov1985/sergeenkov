# Airlines.github.io

This is a [website](https://faisalkhan171101.github.io/Airlines.github.io/) made using Html, css & JavaScript for my IT mini project at Presidency University

The purpose of this project is to implement or to design a database for an airline reservation system to check the flight details,book and cancel flight tickets. It makes the process of booking and cancelling flight tickets simple and easy for the passengers. 

© 2022 Faisal Khan, Presidency University
